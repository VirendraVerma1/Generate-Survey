<?php
ob_start();
header("Location: addfont.php");
	ob_end_flush();
	exit();
?>