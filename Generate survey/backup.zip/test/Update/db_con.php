 <?php 
    $server_database_Connection="localhost";
    $server_database_Username="id8517650_survey";
    $server_database_Password="changesurveyfuture.12";
    $server_database_Name="id8517650_survey";
    
    $con=new mysqli($server_database_Connection,$server_database_Username,$server_database_Password,$server_database_Name);
    
    $server_database_Connection1="localhost";
    $server_database_Username1="id8517650_surveyname";
    $server_database_Password1="changesurveyfuture.21";
    $server_database_Name1="id8517650_surveyname";
    $con1=new mysqli($server_database_Connection1,$server_database_Username1,$server_database_Password1,$server_database_Name1);
?>