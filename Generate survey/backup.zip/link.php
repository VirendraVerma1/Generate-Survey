<?php
$website_name="generatesurvey.000webhostapp.com/";
?>