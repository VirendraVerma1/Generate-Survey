<html>
    <head>
         <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-5870321000407115",
    enable_page_level_ads: true
  });
</script>
        <title>CreateSurvey</title>
    </head>
    <script>
        window.location.replace("http://generatesurvey.000webhostapp.com/homepage.php?create-survey");
    </script>
</html>
<?php
//https://createsurvey.000webhostapp.com/survey.php?surveyname=Game_Addiction&&user=1&&survey=24&&page=1
?>